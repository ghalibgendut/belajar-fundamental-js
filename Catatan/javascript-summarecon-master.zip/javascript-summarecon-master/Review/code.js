var string = 'asdgghjjkhkh';
var search = 'g';
var regex = new RegExp( search, 'g' );

console.log(
    string.match(regex)
)