// Tipe data Boolean : true , false

// var rain = false

// if(rain){
//     console.log('Gunakan payung')
// } else {
//     console.log('Tidak menggunakan payung')
// }

// var age = 46
// var kategori

// if(age >= 0 && age <= 5){
//     kategori = "balita"
// } else if (age >= 6 && age <= 11){
//     kategori = "Kanak - Kanak"
// } else if (age >= 12 && age <= 25){
//     kategori = "Remaja"
// } else if (age >= 26 && age <= 45){
//     kategori = "Dewasa"
// } else if (age >= 46 && age <= 65){
//     kategori = "Lansia"
// } else {
//     kategori = "Manula"
// }

// console.log(kategori)

// PERBANDINGAN
// < , > , <=, >=, ==, ===

// console.log(5 == 5)
// console.log(5 === 5)
// // Tipe data akan diabaikan
// console.log(5 == "5")
// // Tipe data diperhitungkan
// console.log(5 === "5")

// LOGIKA
// AND OR NOT

// SWITCH CASE
// Akan mencocokan data / value / nilai 
// yang ada pada switch dan case
var rain = 'gerimis'
switch (false) {
    case 6 < 3:
        console.log("Hujan deras nih")
        break;

    case 'hujan sedang':
        console.log("Hujan sedang nih")
        break;

    case 'gerimis':
        console.log("Gerimish nih")
        break;

    default:
        console.log("Cerah")
        break;
}

