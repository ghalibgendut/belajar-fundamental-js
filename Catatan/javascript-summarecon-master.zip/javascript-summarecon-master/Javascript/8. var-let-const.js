// SCOPE VARIABLE
// Darimana sebuah variable dapat diakses

// VAR
// Dibatasi oleh function

// Global variable
// var y = 40

// var hello = () => {
    

//     console.log('Dalam function : ' + x)
// }

// hello()
// console.log('Di luar function : ' + x)

// LET
// Dibatasi oleh function, kurung kurawal

// if (true){
//     var nameVar = "jordan"
// }

// do {
//     var nameVar = "jordan"
// } while (false);

// if (true) {
//     let nameLet = "Max"
// }

// do {
//     let nameLet = "Max"
// } while (false);

// console.log("var nameVar : " + nameVar);
// console.log("let nameLet : " + nameLet);


// CONST
// Dibatasi oleh function, kurung kurawal
// Nilainya tidak bisa di ubah (no re-assignment)

// const price = 10000