// default : 0.0 - 0.9
// 1 - 100
// dikali 100 ditambah 1
var result = parseInt((Math.random() * 100) + 1)

console.log(result)