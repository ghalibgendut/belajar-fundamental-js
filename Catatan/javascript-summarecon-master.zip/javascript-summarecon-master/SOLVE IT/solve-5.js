var totalAge = 49
var rasioAndi = 2, rasioBudi = 5, totalRasio = 7

var ageAndi = totalAge * (rasioAndi / totalRasio)
ageAndi += 2

var ageBudi = totalAge * (rasioBudi / totalRasio)
ageBudi += 2

console.log(
    `Usia Andi : ${ageAndi} tahun\n` +
    `Usia Budi : ${ageBudi} tahun`
)