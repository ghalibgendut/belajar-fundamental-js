var x = 4, y = 3, z = 2

var w = ((x + y * z) / (x * y)) ** z

console.log(w)