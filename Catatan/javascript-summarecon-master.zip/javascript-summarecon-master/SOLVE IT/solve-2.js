var number = parseInt(prompt('Masukkan Angka :'))

var result = number ** 2

alert(
    `Kuadrat dari ${number} = ${result} `
)