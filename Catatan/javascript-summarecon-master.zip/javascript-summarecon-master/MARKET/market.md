## MARKET V7.0

- App tidak lagi hanya menjual buah, melainkan menjual tiga product lainnya, sehingga kini app akan menjual empat macam product, yaitu :
    1. Makanan Cepat Saji (FastFood)
        - Properties : category, name, price, stock, expired, qty, total
    2. Pakaian (Cloth)
        - Properties : category, name, price, stock, size, qty, total
    3. Elektronik (Electronic)
        - Properties : category, name, price, stock, warranty,  qty, total
    4. Buah (Fruit)
        - Properties : category, name, price, stock, sugarLvl, qty, total
- Kini user boleh memilih untuk product apa saja yang ingin dibeli, tidak harus semua
- Ketika user ingin belanja dengan product yang sama, qty akhir akan di akumulasi dengan qty sebelumnya.
- Ketika user memilih untuk membeli sejumlah qty tertentu, stock akan berkurang
    - Contoh Apel ada 5, ketika belanja pertama membeli 2 maka tinggal 3, belanja berikutnya tidak bisa membeli apel lebih dari 3.
- Keterangan detail product hanya mencantumkan barang yang dibeli saja
- Tambahkan menu ke 4 yaitu keluar dari aplikasi
- Gunakan Class dalam project ini.