# Table V2

- Filter name
  - onChange
  - includes()
  - toLowerCase()

- Filter harga
  - onChange
  - Filter ketika harga minimal dan maksimal ditulis

- Filter category
  - onChange